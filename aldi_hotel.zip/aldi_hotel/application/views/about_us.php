<div class="container">
  <div class="row">
    <div class="col-md-12" style="margin-top: 60px;">
      <center><h4 class="text-purple">About Us</h4></center>
      <p>The Trans Luxury Hotel adalah akomodasi yang telah mengharumkan Indonesia di tingkat internasional setelah dinobatkan sebagai “Asia's Leading Business Hotel” pada ajang penghargaan bergengsi World Travel Awards 2019. Hotel ini juga mendapatkan nominasi sebagai “Asia's Leading Business Hotel” dan “Indonesia's Leading Business Hotel”. The Trans Luxury Hotel berhasil bersaing dengan berbagai hotel international chain seperti Fairmont Hotel, The Ritz-Carlton Hotel, The St. Regis Hotel, Conrad Hotel, dan masih banyak lagi lainnya di berbagai negara di Asia seperti Jepang, Hong Kong, Thailand, Filipina, Singapura, juga India.


The Trans Luxury Hotel menjadi satu-satunya hotel dengan brand lokal dari Indonesia yang dinominasikan dalam World Travel Awards. Selain itu, hotel ini juga menjadi Traveller’s Choice dan mendapatkan Certificate of Excellence dari Trip Advisor, juga mendapatkan kehormatan menerima "The Seven Stars Global Luxury Awards’. Dengan berbagai penghargaan tersebut menjadikan The Trans Luxury Hotel diakui sebagai hotel yang berhasil memberikan fasilitas dan pelayanan terbaik dalam mendukung kegiatan bisnis para pelancong..</p>
    </div>
  </div>
</div>